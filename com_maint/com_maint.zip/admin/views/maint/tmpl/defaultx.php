<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
// load tooltip behavior
JHtml::_('behavior.tooltip');
?>
asdasddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd
<style>
@import url(components/com_maint/assets/css/admin.css);
</style>
