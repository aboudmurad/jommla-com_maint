<?php
// No direct access
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.tooltip');
?>
<style>
@import url(components/com_maint/assets/css/admin.css);
</style>
dsasdasdadasddddddddddddddddddd