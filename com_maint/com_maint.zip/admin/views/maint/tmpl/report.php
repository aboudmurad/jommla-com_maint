<?php
// No direct access
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.tooltip');
?>
sadjkashkjahdjahdsjkhdjksahasjk