<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
	<th width="6">
		الرقم
	</th>
	<th width="20">
<!--		<input type="radio" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" />-->
	</th>

    <th>
			إسم العميل
		</th>
		<th>
			الهاتف
		</th>
        		<th>
			خلوي
		</th>
		<th>
			بريد الكتروني
		</th>
    <th>
			نوع الجهاز
		</th>
        
    <th>
			تم العمل
		</th>
		<th>
			مبلغ كلي
		</th>
		<th>
			مبلغ مٌخفّض
		</th>
		<th>
			مبلغ مدفوع
		</th>
		<th>
			مبلغ متبقي
		</th>
		<th>
			تاريخ دخول
		</th>

		<th>
			تاريخ إصلاح
		</th>

    <th>
			تاريخ استلام
		</th>


</tr>
