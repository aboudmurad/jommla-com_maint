<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
    <tr>
      <td colspan="9"><div class="container"><?php echo $this->pagination->getListFooter(); ?></div></td>
    </tr>
