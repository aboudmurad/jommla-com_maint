DROP TABLE IF EXISTS `#__maint_clients`;
DROP TABLE IF EXISTS `#__maint_orders`;
